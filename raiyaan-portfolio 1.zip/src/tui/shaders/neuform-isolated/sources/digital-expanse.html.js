const e = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue 01 — Expanse Field</title>
    
    <!-- Frameworks & Animations -->
    <script src="https://cdn.tailwindcss.com"><\/script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"><\/script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js"><\/script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\/script>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"><\/script>
</head>
<body class="bg-[#f6f5f4] text-neutral-900 antialiased selection:bg-neutral-900 selection:text-white" 
      style="font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">

    <!-- WebGL Background Context -->
    <canvas id="glcanvas" class="fixed inset-0 w-full h-full -z-10 pointer-events-none"></canvas>

    <!-- Subtle Diagonal Texture Overlay -->
    <div class="fixed inset-0 pointer-events-none -z-10" 
         style="background-image: repeating-linear-gradient(45deg, rgba(0,0,0,0.015) 0, rgba(0,0,0,0.015) 1px, transparent 1px, transparent 6px);">
    </div>

    <!-- Global Framed Grid System -->
    <div class="fixed inset-4 md:inset-6 pointer-events-none z-50 flex flex-col justify-between mix-blend-difference text-white/50"
         style="border: 1px solid rgba(255,255,255,0.15); border-image: linear-gradient(to bottom, rgba(255,255,255,0.1), rgba(255,255,255,0.3), rgba(255,255,255,0.1)) 1;">
        
        <!-- Corner Brackets -->
        <div class="absolute -top-[1px] -left-[1px] w-5 h-5 border-t border-l border-white/60"></div>
        <div class="absolute -top-[1px] -right-[1px] w-5 h-5 border-t border-r border-white/60"></div>
        <div class="absolute -bottom-[1px] -left-[1px] w-5 h-5 border-b border-l border-white/60"></div>
        <div class="absolute -bottom-[1px] -right-[1px] w-5 h-5 border-b border-r border-white/60"></div>

        <!-- Structural Guide Lines -->
        <div class="absolute left-[33.33%] top-0 bottom-0 w-[1px] bg-white/10 hidden md:block"></div>
        <div class="absolute right-[33.33%] top-0 bottom-0 w-[1px] bg-white/10 hidden md:block"></div>
    </div>

    <!-- Document Content -->
    <main class="w-full relative z-10">

        <!-- PAGE 01: COVER -->
        <section id="cover" class="relative min-h-screen p-6 md:p-12 flex flex-col pt-16 md:pt-24 pb-12">
            
            <!-- Masthead -->
            <header class="flex justify-between items-start mb-16 md:mb-24 relative z-20 mix-blend-difference text-white">
                <div class="text-xs uppercase tracking-widest font-medium">Issue Nº 01</div>
                <div class="text-xs uppercase tracking-widest font-medium text-right leading-tight">
                    Vol. 1 <br>
                    <span class="text-white/60">Aura Asset Library</span>
                </div>
            </header>

            <!-- Cover Layout Grid -->
            <div class="flex-1 grid grid-cols-1 md:grid-cols-3 gap-8 relative z-20 h-full items-end pb-12 md:pb-0">
                
                <!-- Left: Typography -->
                <div class="col-span-1 md:col-span-2 flex flex-col justify-end order-2 md:order-1">
                    <h1 class="text-6xl md:text-[9vw] leading-[0.8] tracking-tight font-semibold mix-blend-difference text-white uppercase" 
                        style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
                        Digital<br>Artifacts
                    </h1>
                    <div class="mt-8 md:mt-12 max-w-sm mix-blend-difference text-white/70">
                        <p class="text-sm font-normal leading-relaxed">
                            Exploring the intersection of generative environments, raw computational textures, and structured grid systems to establish physical presence in the void.
                        </p>
                    </div>
                </div>

                <!-- Right: Featured Asset -->
                <div class="col-span-1 flex items-center justify-center md:justify-end order-1 md:order-2 h-full pb-8 md:pb-0">
                    <div class="relative w-full max-w-sm aspect-[4/5] p-2 bg-black/5 backdrop-blur-md"
                         style="border: 1px solid rgba(255,255,255,0.1); border-image: linear-gradient(to bottom right, rgba(255,255,255,0.4), rgba(255,255,255,0.05)) 1;">
                         <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/4f5668c5-fc4a-44e0-bc5e-a664189d3c31_1600w.jpg" 
                              class="w-full h-full object-cover filter grayscale contrast-125 opacity-90 mix-blend-luminosity" 
                              alt="Cover Feature Portrait">
                         
                         <!-- Image Container Corner Details -->
                         <div class="absolute top-2 left-2 w-3 h-3 border-t border-l border-white/60 mix-blend-difference"></div>
                         <div class="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-white/60 mix-blend-difference"></div>
                    </div>
                </div>
            </div>

            <!-- Footer Barcode -->
            <div class="mt-auto flex justify-between items-end relative z-20 mix-blend-difference text-white">
                <div class="text-xs font-mono uppercase tracking-widest flex items-center gap-3">
                    <iconify-icon icon="solar:barcode-line" class="text-3xl opacity-80" stroke-width="1.5"></iconify-icon>
                    <span>978-1-2345-678-0</span>
                </div>
                <div class="text-[10px] md:text-xs uppercase tracking-widest flex items-center gap-2">
                    Scroll <iconify-icon icon="solar:arrow-down-linear" class="text-sm"></iconify-icon>
                </div>
            </div>
        </section>

        <!-- PAGE 02: ARTICLE SPREAD -->
        <section id="page-2" class="relative min-h-screen bg-[#f6f5f4] p-6 md:p-12 flex flex-col justify-center shadow-[0_-20px_50px_rgba(0,0,0,0.1)]">
             <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-16 h-full items-center">
                
                <!-- Left Figure -->
                <div id="figure-img" class="md:col-span-4 flex flex-col justify-between h-full py-12 md:py-24">
                    <div class="text-[10px] uppercase tracking-widest font-medium text-neutral-400 mb-6 border-b border-neutral-300 pb-2 inline-block max-w-fit">
                        [ Fig. 01 ]
                    </div>
                    <div class="relative overflow-hidden aspect-[3/4]">
                        <img src="https://hoirqrkdgbmvpwutwuwj.supabase.co/storage/v1/object/public/assets/assets/724142aa-44a6-48d3-9cf3-761e00d05b78_1600w.jpg" 
                             class="w-full h-full object-cover filter grayscale contrast-125" 
                             alt="Deconstructed Pyramid Architecture">
                    </div>
                    <div class="text-[10px] uppercase tracking-widest mt-6 text-neutral-500 flex justify-between">
                        <span>Architecture</span>
                        <span>001</span>
                    </div>
                </div>

                <!-- Right Editorial Text -->
                <div class="md:col-span-8 md:pl-12 pt-8 md:pt-0">
                    <div class="text-xs uppercase tracking-widest font-medium text-neutral-400 mb-8 flex items-center gap-2">
                        <iconify-icon icon="solar:document-text-linear" class="text-base"></iconify-icon> Index Introduction
                    </div>
                    
                    <!-- GSAP Stagger Reveal Target -->
                    <div id="stagger-text" class="text-3xl md:text-5xl lg:text-[3.5vw] leading-[1.05] tracking-tight font-medium text-neutral-900">
                        The evolution of surface interfaces demands a departure from sterile environments. We look towards raw noise and structured grids to ground logic in physical realism.
                    </div>

                    <div class="mt-12 md:mt-20 flex flex-col md:flex-row gap-8 md:gap-12 text-sm font-normal text-neutral-600 leading-relaxed border-t border-neutral-200 pt-8">
                        <p class="flex-1">
                            By manipulating fragments of light through mathematical shaders, we simulate the imperfections of analog film. The resulting grain breathes life into rigid columns, oscillating to mimic a natural rhythm within strict constraints.
                        </p>
                        <p class="flex-1">
                            This intersection of organic distortion and rigid geometry creates a meditative atmosphere. It is not merely a background, but a dynamic environment that continuously responds to time and structure.
                        </p>
                    </div>
                </div>
             </div>
        </section>

    </main>

    <!-- Logic & Shaders -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            
            // -----------------------------------------------------
            // 1. WebGL Background Setup (Three.js)
            // -----------------------------------------------------
            const initWebGL = () => {
                const canvas = document.getElementById('glcanvas');
                const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false });
                renderer.setSize(window.innerWidth, window.innerHeight);
                renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

                const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
                const scene = new THREE.Scene();
                const geometry = new THREE.PlaneGeometry(2, 2);

                const uniforms = {
                    u_time: { value: 0.0 },
                    u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) }
                };

                const material = new THREE.ShaderMaterial({
                    uniforms: uniforms,
                    vertexShader: \`
                        void main() {
                            gl_Position = vec4(position, 1.0);
                        }
                    \`,
                    fragmentShader: \`
                        uniform vec2 u_resolution;
                        uniform float u_time;

                        float random(vec2 st) {
                            return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
                        }

                        void main() {
                            vec2 st = gl_FragCoord.xy / u_resolution.xy;
                            float numBars = 11.0;
                            float barIndex = floor(st.x * numBars);
                            float t = barIndex / (numBars - 1.0);

                            // Breathing pulse animation
                            float anim = sin(u_time * 0.5 + t * 3.0) * 0.025;

                            // Curve for horizon line
                            float targetHeight = 0.15 + pow(t, 1.3) * 0.5 + anim;

                            // Color gradient: Dark base -> Blue/Pink mid -> Cutoff
                            vec3 colorBase = vec3(0.04, 0.04, 0.06);
                            vec3 colorMid = mix(vec3(0.1, 0.3, 0.8), vec3(0.8, 0.2, 0.5), st.x);
                            vec3 color = mix(colorBase, colorMid, smoothstep(0.1, 0.7, st.y));

                            // Stepped horizon cutoff matching body background
                            if (st.y > targetHeight) {
                                gl_FragColor = vec4(0.965, 0.961, 0.957, 1.0); // #f6f5f4
                                return;
                            }

                            // High-frequency film grain
                            float noise = random(st * (u_time * 0.1)) * 0.15;
                            gl_FragColor = vec4(color + noise, 1.0);
                        }
                    \`,
                    transparent: true
                });

                const mesh = new THREE.Mesh(geometry, material);
                scene.add(mesh);

                const animate = (time) => {
                    uniforms.u_time.value = time * 0.001;
                    renderer.render(scene, camera);
                    requestAnimationFrame(animate);
                };
                requestAnimationFrame(animate);

                window.addEventListener('resize', () => {
                    renderer.setSize(window.innerWidth, window.innerHeight);
                    uniforms.u_resolution.value.set(window.innerWidth, window.innerHeight);
                });
            };

            // -----------------------------------------------------
            // 2. GSAP Interactions & Masked Text Reveal
            // -----------------------------------------------------
            const initGSAP = () => {
                gsap.registerPlugin(ScrollTrigger);

                // Entry Animation for Cover
                const tl = gsap.timeline({ defaults: { ease: "expo.out" } });
                tl.fromTo("#cover h1", { y: 60, opacity: 0 }, { y: 0, opacity: 1, duration: 2, delay: 0.2 })
                  .fromTo("#cover p", { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 1.5 }, "-=1.5")
                  .fromTo("#cover img", { scale: 1.1, filter: "blur(10px)", opacity: 0 }, { scale: 1, filter: "blur(0px)", opacity: 0.9, duration: 2.5 }, "-=1.8");

                // Text Splitter Utility for Masked Reveal
                const textElement = document.getElementById('stagger-text');
                const words = textElement.innerText.trim().split(' ');
                textElement.innerHTML = '';

                words.forEach(word => {
                    const wordWrap = document.createElement('span');
                    // Style inline to avoid external CSS
                    wordWrap.style.display = 'inline-block';
                    wordWrap.style.overflow = 'hidden';
                    wordWrap.style.marginRight = '0.2em';
                    wordWrap.style.paddingBottom = '0.1em'; // Prevent clipping bottom of letters
                    wordWrap.style.verticalAlign = 'top';

                    const innerSpan = document.createElement('span');
                    innerSpan.innerText = word;
                    innerSpan.style.display = 'inline-block';
                    innerSpan.classList.add('reveal-word');

                    wordWrap.appendChild(innerSpan);
                    textElement.appendChild(wordWrap);
                });

                // ScrollTrigger: Masked Stagger Reveal
                gsap.fromTo('.reveal-word', 
                    { y: '110%', rotationZ: 4 }, 
                    {
                        y: '0%',
                        rotationZ: 0,
                        duration: 1.2,
                        ease: "power4.out",
                        stagger: 0.03,
                        scrollTrigger: {
                            trigger: '#stagger-text',
                            start: "top 85%",
                            toggleActions: "play none none reverse"
                        }
                    }
                );

                // Subtle Image Parallax on Page 2
                gsap.fromTo('#figure-img img', 
                    { yPercent: -15, scale: 1.1 },
                    {
                        yPercent: 15,
                        scale: 1,
                        ease: "none",
                        scrollTrigger: {
                            trigger: '#page-2',
                            start: "top bottom",
                            end: "bottom top",
                            scrub: true
                        }
                    }
                );
            };

            // Initialize
            initWebGL();
            initGSAP();
        });
    <\/script>
</body>
</html>`;
export {
  e as default
};
